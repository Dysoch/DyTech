data:extend(
{
  {
    type = "item",
    name = "research-system",
    icon = "__base__/graphics/icons/iron-ore.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "checker-items",
    order = "research-system",
    stack_size = 1,
  },
}
)
