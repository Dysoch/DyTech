data:extend(
{
  {
	type = "item",
	name = "item-collector-area",
	icon = "__MAIN-DyTech-Dynamics__/graphics/smart-chest-icon.png",
	flags = {"goes-to-quickbar"},
	subgroup = "storage",
	order = "i[item-collector]",
	place_result = "item-collector-area",
	stack_size = 50
  },
})