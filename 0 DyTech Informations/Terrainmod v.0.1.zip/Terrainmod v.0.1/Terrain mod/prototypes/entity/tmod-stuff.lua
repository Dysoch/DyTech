  data:extend(
{
  {
    type = "corpse",
    name = "skeleton",
    icon = "__Terrain mod__/graphics/icons/skeleton.png",
    flags = {"placeable-neutral", "player-creation"},
    final_render_layer = "remnants",
    animation = 
    {
      {
        frame_width = 100,
        frame_height = 100,
        frame_count = 1,
        direction_count = 1,
        filename = "__Terrain mod__/graphics/entity/skeletons/skeleton_01.png"
      },
	  {
        frame_width = 100,
        frame_height = 100,
        frame_count = 1,
        direction_count = 1,
        filename = "__Terrain mod__/graphics/entity/skeletons/skeleton_02.png"
      },
	  {
        frame_width = 100,
        frame_height = 100,
        frame_count = 1,
        direction_count = 1,
        filename = "__Terrain mod__/graphics/entity/skeletons/skeleton_03.png"
      },
	  {
        frame_width = 100,
        frame_height = 100,
        frame_count = 1,
        direction_count = 1,
        filename = "__Terrain mod__/graphics/entity/skeletons/skeleton_04.png"
      },
	  {
        frame_width = 100,
        frame_height = 100,
        frame_count = 1,
        direction_count = 1,
        filename = "__Terrain mod__/graphics/entity/skeletons/skeleton_05.png"
      },
	  {
        frame_width = 100,
        frame_height = 100,
        frame_count = 1,
        direction_count = 1,
        filename = "__Terrain mod__/graphics/entity/skeletons/skeleton_06.png"
      }
    }
  },
  {
    type = "corpse",
    name = "wall-corpse-permanent",
    icon = "__base__/graphics/icons/wall.png",
    flags = {"placeable-neutral", "player-creation"},
    final_render_layer = "remnants",
    animation = 
    {
      {
        frame_width = 36,
        frame_height = 36,
        frame_count = 1,
        direction_count = 1,
        filename = "__base__/graphics/entity/wall/remains/wall-remain-01.png"
      },
      {
        frame_width = 38,
        frame_height = 35,
        frame_count = 1,
        direction_count = 1,
        filename = "__base__/graphics/entity/wall/remains/wall-remain-02.png"
      },
      {
        frame_width = 35,
        frame_height = 36,
        frame_count = 1,
        direction_count = 1,
        filename = "__base__/graphics/entity/wall/remains/wall-remain-03.png"
      },
      {
        frame_width = 41,
        frame_height = 36,
        frame_count = 1,
        direction_count = 1,
        filename = "__base__/graphics/entity/wall/remains/wall-remain-04.png"
      },
      {
        frame_width = 35,
        frame_height = 35,
        frame_count = 1,
        direction_count = 1,
        filename = "__base__/graphics/entity/wall/remains/wall-remain-05.png"
      },
      {
        frame_width = 50,
        frame_height = 37,
        frame_count = 1,
        direction_count = 1,
        filename = "__base__/graphics/entity/wall/remains/wall-remain-06.png"
      },
      {
        frame_width = 54,
        frame_height = 40,
        frame_count = 1,
        direction_count = 1,
        filename = "__base__/graphics/entity/wall/remains/wall-remain-07.png"
      },
      {
        frame_width = 43,
        frame_height = 45,
        frame_count = 1,
        direction_count = 1,
        filename = "__base__/graphics/entity/wall/remains/wall-remain-08.png"
      }
    }
  },

  {
    type = "corpse",
    name = "creeper-corpse",
	icon = "__Terrain mod__/graphics/icons/creeper.png",
    flags = {"placeable-neutral", "player-creation"},
    final_render_layer = "remnants",
    animation =
    {
      filename = "__Terrain mod__/graphics/entity/creeper-corpse/creeper-corpse.png",
      frame_width = 87,
      frame_height = 96,
      frame_count = 15,
      direction_count = 9,
      shift = {0.140625, -0.734375}
    },
   },
   {
    type = "unit",
    name = "creeper",
    icon = "__Terrain mod__/graphics/icons/creeper.png",
    flags = {"placeable-player", "placeable-enemy", "placeable-off-grid", "breaths-air"},
    max_health = 30,
	resistances = 
    {
      {
        type = "physical",
        decrease = 4,
      },
      {
        type = "explosion",
        percent = 20
      }
    },
	healing_per_tick = 0.01,
    collision_box = {{-0.2, -0.4}, {0.2, 0}},
    selection_box = {{-0.7, -1.5}, {0.7, 0.3}},
	sticker_box = {{-0.3, -0.5}, {0.3, 0.1}},
	distraction_cooldown = 300,
    attack_parameters =
	{
	 ammo_category = "melee",
     ammo_type = make_unit_melee_ammo_type(15),
     range = 0.8,
     cooldown = 35,
	 animation =
     {
       filename = "__Terrain mod__/graphics/entity/creeper/creeper-attack.png",
       priority = "high",
       frame_width = 63,
       frame_height = 96,
       frame_count = 15,
       direction_count = 9,
       shift = {0.421875, -0.53125}
     },
	},
    movement_speed = 0.185,
    distance_per_frame = 0.15,
	pollution_to_join_attack = 50000,
	corpse = "creeper-corpse",
    dying_sound =
    {
      {
        filename = "__Terrain mod__/sound/creeper-death-1.wav",
        volume = 0.7
      },
      {
        filename = "__Terrain mod__/sound/creeper-death-2.wav",
        volume = 0.7
      },
      {
        filename = "__Terrain mod__/sound/creeper-death-3.wav",
        volume = 0.7
      },
      {
        filename = "__Terrain mod__/sound/creeper-death-4.wav",
        volume = 0.7
      }
    },
    run_animation =
    {
      filename = "__Terrain mod__/graphics/entity/creeper/creeper-run.png",
      priority = "high",
      frame_width = 48,
      frame_height = 68,
      frame_count = 30,
      direction_count = 9,
      shift = {0, -0.75}
    }
   }
}
)