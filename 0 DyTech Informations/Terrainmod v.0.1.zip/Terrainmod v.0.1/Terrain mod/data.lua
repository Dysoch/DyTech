require("prototypes.entity.tmod-stuff")



-- Impassable hills:

data.raw["tile"]["hills"].collision_mask = {
	  "water-tile",
      "ground-tile",
      "resource-layer",
      "floor-layer",
      "item-layer",
      "object-layer",
      "player-layer"
    }
	
data.raw["tile"]["hills"].generator.layer = 6
data.raw["tile"]["hills"].layer = 35
data.raw["tile"]["sand"].generator.layer = 5
data.raw["tile"]["sand"].layer = 30




-- Minimap recolor:

data.raw["tile"]["grass"].map_color={r=0.392, g=0.368, b=0.149}
data.raw["tile"]["dirt"].map_color={r=0.333, g=0.270, b=0.196}
data.raw["tile"]["hills"].map_color={r=0.133, g=0.125, b=0.113}
data.raw["tile"]["sand"].map_color={r=0.466, g=0.419, b=0.356}

data.raw["resource"]["copper-ore"].map_color = {r=0.803, g=0.388, b=0.215}
data.raw["resource"]["iron-ore"].map_color = {r=0.517, g=0.694, b=0.709}
data.raw["resource"]["coal"].map_color = {r=0.670, g=0.956, b=0.654}
data.raw["resource"]["stone"].map_color = {r=0.745, g=0.741, b=0.717}