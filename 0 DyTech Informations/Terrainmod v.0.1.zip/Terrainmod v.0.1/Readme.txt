Terrain mod v.01


Changes:
-Adds impassable hills to the game.

-Terrain graphics tweaks for the hills, and a snowy tile set.
 
-Adds a few props and critters for map editing.(Permanent wall ruin, bones, old Creeper)

-Mini-map color changes, it improves visibility for me at least.





Install:

Copy Terrain mod folder into your mods directory. 

Use one of the tile set packs from the Tilesets folder (drag into main game folder and allow replacement). The originals are included so you can use those to restore the game to ver 0.7.1.6796. (The packs only contain tile set graphics and trees, nothing else is touched)


Mini-map recoloring is in the terrain mod/data.lua if you want to disable it.